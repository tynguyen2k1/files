# My nvim

### Screenshots
![Pic1](https://raw.githubusercontent.com/tynguyen2k1/files/main/Screenshot_20211117_215644.png)
